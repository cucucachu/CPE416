#ifndef NEURALNETWORK
#define NEURALNETWORK

#include "Neuron.h"
#include <stdint.h>

typedef struct NeuralNetwork {
	Neuron **neurons;
	Neuron **input_neurons;
	Neuron **output_neurons;
	
	uint8_t num_input_neurons;
	uint8_t num_output_neurons;
	uint8_t num_neurons;
} NeuralNetwork;

NeuralNetwork *create_neural_network(uint8_t num_neurons, uint8_t num_input_neurons, uint8_t num_output_neurons);
void destroy_neural_network(NeuralNetwork *this);

void connect_neurons(NeuralNetwork *this, uint8_t input, uint8_t output, float weight);
void set_offset(NeuralNetwork *this, uint8_t neuron, float offset);

void set_inputs(NeuralNetwork *this, float *inputs);
float get_output(NeuralNetwork *this, uint8_t neuron);
void get_outputs(NeuralNetwork *this, float *outputs);



#endif
